<?php 
/* utf8-marker = äöüß */ 
################## Data fields ############
$page_data_fields[] = 'url';
$page_data_fields[] = 'last_edit';
$page_data_fields[] = 'description';
$page_data_fields[] = 'keywords';
$page_data_fields[] = 'title';
$page_data_fields[] = 'robots';
$page_data_fields[] = 'heading';
$page_data_fields[] = 'show_heading';
$page_data_fields[] = 'template';
$page_data_fields[] = 'published';
$page_data_fields[] = 'show_last_edit';
$page_data_fields[] = 'linked_to_menu';
$page_data_fields[] = 'header_location';
$page_data_fields[] = 'use_header_location';
$page_data_fields[] = 'sitetitle';
$page_data_fields[] = 'show_sitetitle';

################## Recently deleted ############
$temp_data['url'] = 'Startseite';
$temp_data['last_edit'] = '1251465256';
$temp_data['description'] = '';
$temp_data['keywords'] = '';
$temp_data['title'] = '';
$temp_data['robots'] = '';
$temp_data['heading'] = '';
$temp_data['show_heading'] = '';
$temp_data['template'] = '';
$temp_data['published'] = '';
$temp_data['show_last_edit'] = '';
$temp_data['linked_to_menu'] = '';

################## Page Data ############
$page_data[0]['url'] = 'Welcome_to_CMSimple';
$page_data[0]['last_edit'] = '1353012768';
$page_data[0]['description'] = '';
$page_data[0]['keywords'] = '';
$page_data[0]['title'] = '';
$page_data[0]['robots'] = '';
$page_data[0]['heading'] = '';
$page_data[0]['show_heading'] = '';
$page_data[0]['template'] = '';
$page_data[0]['published'] = '';
$page_data[0]['show_last_edit'] = '';
$page_data[0]['linked_to_menu'] = '1';
$page_data[0]['header_location'] = '';
$page_data[0]['use_header_location'] = '';
$page_data[0]['sitetitle'] = '';
$page_data[0]['show_sitetitle'] = '';

//----------
$page_data[1]['url'] = 'News01';
$page_data[1]['last_edit'] = '1316870463';
$page_data[1]['description'] = '';
$page_data[1]['keywords'] = '';
$page_data[1]['title'] = '';
$page_data[1]['robots'] = '';
$page_data[1]['heading'] = '';
$page_data[1]['show_heading'] = '0';
$page_data[1]['template'] = '0';
$page_data[1]['published'] = '1';
$page_data[1]['show_last_edit'] = '0';
$page_data[1]['linked_to_menu'] = '0';
$page_data[1]['header_location'] = '';
$page_data[1]['use_header_location'] = '0';
$page_data[1]['sitetitle'] = '';
$page_data[1]['show_sitetitle'] = '';

//----------
$page_data[2]['url'] = 'News02';
$page_data[2]['last_edit'] = '1316870483';
$page_data[2]['description'] = '';
$page_data[2]['keywords'] = '';
$page_data[2]['title'] = '';
$page_data[2]['robots'] = '';
$page_data[2]['heading'] = '';
$page_data[2]['show_heading'] = '0';
$page_data[2]['template'] = '0';
$page_data[2]['published'] = '1';
$page_data[2]['show_last_edit'] = '0';
$page_data[2]['linked_to_menu'] = '0';
$page_data[2]['header_location'] = '';
$page_data[2]['use_header_location'] = '0';
$page_data[2]['sitetitle'] = '';
$page_data[2]['show_sitetitle'] = '';

//----------
$page_data[3]['url'] = 'News03';
$page_data[3]['last_edit'] = '1316870492';
$page_data[3]['description'] = '';
$page_data[3]['keywords'] = '';
$page_data[3]['title'] = '';
$page_data[3]['robots'] = '';
$page_data[3]['heading'] = '';
$page_data[3]['show_heading'] = '0';
$page_data[3]['template'] = '0';
$page_data[3]['published'] = '1';
$page_data[3]['show_last_edit'] = '0';
$page_data[3]['linked_to_menu'] = '0';
$page_data[3]['header_location'] = '';
$page_data[3]['use_header_location'] = '0';
$page_data[3]['sitetitle'] = '';
$page_data[3]['show_sitetitle'] = '';

//----------
?>