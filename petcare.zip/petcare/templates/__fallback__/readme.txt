======================================
 CMSimple Standard (default) Template
======================================

---------------------
 Deutsch
---------------------

- Das linke Headerbild ist die Datei ./templates/das-template/images/logo.jpg. Sie k�nnen unter diesem Namen ein anderes Bild oder Ihr Logo hochladen. 

- Die logo.jpg sollte eine H�he von 100px haben. Sonst k�nnten Anpassungen in der stylesheet.jpg notwendig werden.


---------------------
 English
---------------------

- The left header image is the file ./templates/the-template/images/logo.jpg. You can replace that image by another image or your business logo.

- logo.jpg should be 100px high. Otherwise some changes in the stylesheet.css could be necessary.
