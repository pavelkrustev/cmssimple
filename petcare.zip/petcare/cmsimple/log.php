<?php // utf-8 marker: äöü
if(!defined('CMSIMPLE_VERSION') || preg_match('/log.php/i', $_SERVER['SCRIPT_NAME'])){die('No direct access');} ?>
==============================
2020-12-03 15:17:30 from 172.31.30.63 logged_in: /CMSimple_5-1/ - ""
2020-12-03 15:16:37 from 172.31.30.63 logged_in: /CMSimple_5-1/ - "test"
2020-12-03 15:11:51 from 172.31.30.63 login failed: /CMSimple_5-1/ ##### "test" ##### 
2020-12-03 15:11:36 from 172.31.30.63 login failed: /CMSimple_5-1/ ##### "" ##### 
2020-06-11 14:12:51 from ::1 logged_in: /CMSimple5_Downloads/CMSimple_5-1/ - ""
2020-04-11 14:53:41 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 13:46:42 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 10:54:46 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 10:44:50 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 10:15:08 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:53:55 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:53:32 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:38:33 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:16:11 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:13:11 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:12:47 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:06:22 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:05:13 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 09:05:04 from ::1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-11 08:56:44 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-11 08:56:34 from ::1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-11 08:56:20 from ::1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-10 19:09:23 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/subsite/fr/ - ""
2020-04-10 18:59:19 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/author2/ - ""
2020-04-10 18:58:20 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/subsite/ - ""
2020-04-10 18:57:02 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/fr/ - ""
2020-04-10 18:26:28 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/subsite/ - ""
2020-04-10 18:15:19 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/author2/ - ""
2020-04-10 18:13:01 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/subsite/ - ""
2020-04-10 18:05:57 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/author2/ - ""
2020-04-10 18:05:46 from ::1 login failed: /CMSimple5_Development/cmsimple5rc/author2/ ##### "" ##### 
2020-04-10 17:15:30 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 17:15:21 from ::1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-10 16:36:28 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 16:36:17 from ::1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-10 16:36:07 from ::1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-10 11:38:11 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 10:39:39 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 10:38:03 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 10:30:14 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 10:26:55 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 10:13:28 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 09:53:58 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 09:30:56 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 09:27:16 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 08:47:13 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 08:45:45 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 08:35:26 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 08:33:58 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 08:29:50 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-10 07:32:59 from ::1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 18:41:31 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 18:41:10 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 18:40:57 from 127.0.0.1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-09 16:34:12 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 16:34:05 from 127.0.0.1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-09 14:35:20 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 13:08:48 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 11:44:33 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 11:27:51 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 11:06:16 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 11:01:49 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 10:59:08 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 10:58:52 from 127.0.0.1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-09 10:57:55 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 10:32:24 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 09:04:10 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 08:50:14 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 08:49:36 from 127.0.0.1 logged_in: /CMSimple5_Development/cmsimple5rc/ - ""
2020-04-09 08:49:28 from 127.0.0.1 login failed: /CMSimple5_Development/cmsimple5rc/ ##### "" ##### 
2020-04-08 10:47:09 from ::1 logged_in: /CMSimple5_Downloads/CMSimple_4-8-2/ - ""
2019-10-14 11:53:38 from ::1 logged_in: /CMSimple5_Downloads/CMSimple_4-8/ - ""
2019-10-14 11:53:30 from ::1 login failed: /CMSimple5_Downloads/CMSimple_4-8/ ##### "" ##### 
2019-10-14 11:52:47 from ::1 logged_in: /CMSimple5_Downloads/CMSimple_4-8/ - ""
