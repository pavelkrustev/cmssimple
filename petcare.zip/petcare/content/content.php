<?php // utf8-marker = äöü
if(!defined('CMSIMPLE_VERSION') || preg_match('/content.php/i', $_SERVER['SCRIPT_NAME']))
{
	die('No direct access');
}
?>
<h1 class="_level1_page_">Welcome to CMSimple 5</h1>
<h1 title="G2 PetCare" data-tid="wiki-viewer-title">G2 PetCare</h1>
<p>&nbsp;<img style="float: right;" src="userfiles/images/pomeranian-dog2.jpg" alt="" width="331" height="193"></p>
<div class="ts-wiki-page-content-parent">
<div class="ts-wiki-page-content">
<div class="page-sections">
<div class="wiki-section-and-add">
<div id="section-4" class="ts-wiki-section" tabindex="-1">
<div class="wiki-canvas-inside-section">
<div class="ts-wiki-section-view">
<div class="ts-wiki-viewer">
<div class="ts-wiki-viewer-content-and-marker">
<div id="wiki-viewer-content-4" class="ts-wiki-viewer-content html" tabindex="-1" data-clickable-element="" data-tid="wiki-viewer-content-4">
<div class="copy-paste-block">
<p>Everything necessary for your pet while away is here. For dogs, cats, ferrets, birds ...</p>
<p>3 modes to perfectly match your needs:<br><strong>"G2: PetCare"</strong>&nbsp;for&nbsp;<strong>families with pets</strong><br><strong>"G2: PetWelcome</strong>" for&nbsp;<strong>Pet Hosts</strong><br><strong>"G2: PetReport"</strong>&nbsp;for information exchange between Hosts to Owners</p>
<p>Just&nbsp;<strong>connect</strong>&nbsp;according to your&nbsp;<strong>role.</strong></p>
<p><em>G2: pet care</em>&nbsp;offers everything you need for the best care of your pets while away.&nbsp;<strong>Remember, Monitor, and Care</strong>&nbsp;for all of your pet care needs, ranging from everyday tasks,&nbsp;<strong>medical incidents</strong>&nbsp;and&nbsp;<strong>records</strong>&nbsp;keeping.</p>
<p>G2 truly provides that second hand we all look for when away for our furry friends. We provide&nbsp;<strong>reminders for medical care</strong>, pet specific habits, we offer over&nbsp;<strong>50 features,&nbsp;</strong>everything you need to make sure the pet is in trusted hands to meet the daily care and routines in the most efficient way.</p>
<p>Access your data anywhere, anytime,&nbsp;<strong>even when you are offline.</strong></p>
<p>Completely&nbsp;<strong><u>Free</u></strong>&nbsp;Pet App +&nbsp;<strong><u>Secure backups/</u></strong>&nbsp;to the cloud +&nbsp;<strong><u>No internet connection</u></strong>&nbsp;needed</p>
<p>The application takes care of everything that matters:<br>•  Manage pet medications by logging and setting reminders for medications<br>•  Stay on top with your animal care duties by scheduling activities for owners and hosts</p>
<p>•  Track and report walks and activities for owners and hosts</p>
<p>•  Never lose track with food tracking, walking, sending a picture or two<br>•  Detailed food section with reminders<br>•  Detailed supply tracking to keep track with your food supply levels<br>•  Follow-up records with logged records, photos, and notes<br>•  Maintain owners and hosts data safely stored<br>•  Secure&nbsp;<strong>cloud backups</strong>&nbsp;of your data and photos</p>
<p>With G2 Pet Care 3 pillars: remember, monitor, and care, you are sure to be on top of everything even on your trip. Specifically:</p>
<p><strong>REMEMBER</strong><br>G2 Pet Care makes sure not to let any aspect of their care slip through the cracks.<br>Get daily automatic reminders on every aspect of your pets agreed routine, from their important appointments, to their everyday needs. And with over 50 pre-defined categories for scheduling,11pets allows you to set reminders for:<br>•  Food tracking<br>•  Medication<br>•  Walks<br>•  Photo shoots<br>•  Special routines</p>
<p><strong>MONITOR</strong><br>G2Pet Care app enables you to easily log and monitor all of your pets’ most important data while away. This way, you’re always confident for the best of your pet.<br>•  Pet height<img style="float: right;" src="userfiles/images/hundealter_300x300.jpg" alt="" width="236" height="236"><br>•  Pet weight&nbsp;<br>•  Pet routines</p>
<p>•  Pet walks<br>•  Pet allergies<br>•  Medical incidents<br>•  Lab Documents<br>•  Manage Dog Injections<br>•  Manage Cat Care Records</p>
<p><strong>CARE</strong><br>G2 PetCare makes scheduling bath times, grooming, food and supply tracking easy. Never stress out again about supplies running out, or when to schedule your pet’s next bath! Just create your own pet care calendar, and G2 PetsCare helps you stick to your schedule. Specifically:<br>•  Food tracking<br>•  Bathing<br>•  Walking<br>•  Activities</p>
</div>
</div>
</div>
<div class="acc-hidden-element">&nbsp;</div>
</div>
</div>
</div>
</div>
<div class="post-section" data-tid="canvas-post-section-4">&nbsp;<img src="userfiles/images/thumb_834x469_dogs.jpg" alt="" width="900" height="506"></div>
</div>
</div>
</div>
</div>
<div class="tse-scrollbar simple-scrollbar overflowed">&nbsp;</div>
<h1 class="_level1_page_">Willkommen bei CMSimple 5</h1>
<h1>Willkommen bei CMSimple 5</h1>
<p><img class="tplge_right" src="userfiles/images/coffee.png" alt="">Herzlichen Glückwunsch zu Ihere neuen Installation von <strong>CMSimple</strong>.</p>
<p>Sie müssen nun das Passwort setzen. Wie das geht, erfahren Sie in der <strong><span style="background: #900; color: #fff; padding: 3px 6px;">readme.php</span></strong> im Root Ordner des Downloads.</p>
<p>CMSimple ist veröffentlicht unter GPL3 Lizenz.Mehr Informationen zu CMSimple, die Dokumentation und die aktuellen Downloads finden Sie auf der CMSimple Homepage:</p>
<p><strong><a href="https://www.ge-webdesign.de/">cmsimple.org »</a></strong></p>
<p>Hier finden Sie eine Demo-Website mit CMSimple und vielen Plugins, mit denen die Funktionalität von CMSimple erweitert werden kann:</p>
<p><strong><a href="https://www.ge-webdesign.de/plugindemo/">CMSimple Plugin Demo Seiten »</a></strong></p>
<h2>Die CMSimple Links</h2>
<p>Wenn Sie ein originales oder modifiziertes CMSimple Template nutzen, belassen Sie bitte den Template Link im Template. Sie können diesen Link wie folgt erweitern:</p>
<ul>
<li>Template by <a href="https://www.cmsimple.org">CMSimple</a> - modified by <a href="https://www.cmsimple.org">Ihr Link</a></li>
</ul>
<p>Wenn Sie ein anderes Template nutzen, setzen Sie bitte einen entsprechenden Link zu <a href="https://www.cmsimple.org">www.cmsimple.org</a> in Ihrem Template, um die Popularität von CMSimple zu steigern, so geben Sie etwas zurück an das Projekt CMSimple.</p>
<h1 class="_level1_page_">Menulevels and Headings</h1>
<h1>Menulevels &amp; Headings</h1>
<p>With CMSimple 5 you can use 6 menulevels by default:</p>
<p><strong><a href="?sitemap">Take a look at the full page structure »</a></strong></p>
<p>Headings h1 with the CSS classes&nbsp; "_level<strong>1</strong>_page_ "... "_level<strong>6</strong>_page_"&nbsp; will dynamically split the document into new pages:</p>
<p class="tplge_code">&lt;h1 class="_level1_page_"&gt;Menu Levels and Headings&lt;/h1&gt;</p>
<p>CMSimple includes a pagemanager that simplifies creating, renaming, moving and deleting of pages. Even complete folders with subfolders can be moved or deleted with Pagemanager.</p>
<p>Thus it should be no problem to get rid of the contents of this standard download. Alternatively you could start with the present page structure, rename pages and overwrite the contents.</p>
<h1 class="_level2_page_">Menu Level 2 - Page 1 ...</h1>
<h1>Menu Level 2 - Page 1</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h1 class="_level3_page_">Menu Level 3 - Page 1 ...</h1>
<h1>Menu Level 3 - Page 1</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text. </p>
<h1 class="_level4_page_">MenuLevel 4 Page ...</h1>
<h1>Menu Level 4 Page</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h1 class="_level5_page_">MenuLevel 5 Page ...</h1>
<h1>Menu Level 5 Page</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h1 class="_level6_page_">MenuLevel 6 Page</h1>
<h1>Menu Level 6 Page</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h1 class="_level3_page_">Menu Level 3 - Page 2</h1>
<h1>Menu Level 3 - Page 2</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.</p>
<h1 class="_level3_page_">Menu Level 3 - Page 3</h1>
<h1>Menu Level 3 - Page 3</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.</p>
<h1 class="_level2_page_">Menu Level 2 - Page 2</h1>
<h1>Menu Level 2 - Page 2</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text. </p>
<h1 class="_level2_page_">Menu Level 2 - Page 3</h1>
<h1>Menu Level 2 - Page 3</h1>
<p>In CMSimple5 you can use all headings on a CMSimple page:</p>
<h1>Heading h1</h1>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h2>Heading h2</h2>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h3>Heading h3</h3>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h4>Heading h4</h4>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h5>Heading h5</h5>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;</p>
<h6>Heading h6</h6>
<p>This is a paragraph with some text. This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text.&nbsp;This is a paragraph with some text. </p>
<h1 class="_level1_page_">Templates and Plugins</h1>
<h1>Templates &amp; Plugins</h1>
<p>By using a different template, you can give your pages a completely different look. Some useful plugins can greatly expand the functionality of your CMSimple website.</p>
<div style="text-align: center; font-weight: bold; background: #900; color: #ffffff; padding: 4px 6px;">
<p>While installing templates or plugins, <br> please respect the licensing conditions of the authors.</p>
</div>
<p>Popular plugins provide picture galleries, guest books, comment possibilities, integration of video etc.</p>
<p>Templates and plugins for CMSimple are available on <strong><a href="https://www.ge-webdesign.de/">ge-webdesign.de »</a></strong></p>
<h1 class="_level1_page_">Languages</h1>
<h1>Languages</h1>
<p>The standard download of CMSimple include German and English language files (de.php and en.php).</p>
<p>Please don’t delete the "default" and the "en" language files (default.php and en.php), as they serve as default fallback.</p>
<h1 class="_level1_page_">News01</h1>
<h2>Infobox News01</h2>
<p>This box shows the content of the hidden page "News01".</p>
<p>More information about newsboxes can be found in the documentation on</p>
<p style="text-align: right;"><a href="https://www.cmsimple.org/doku/en/?Working_with_CMSimple___Newsboxes">cmsimple.org »</a></p>
<hr>
<p>Diese Box zeigt den Inhalt der versteckten Seite "News01".</p>
<p>Mehr Informationen zum Thema Newsboxen gibt es in der Dokumentation auf</p>
<p style="text-align: right;"><a href="https://www.cmsimple.org/doku/?Arbeiten_mit_CMSimple___Newsboxen">cmsimple.org »</a></p>
<h1 class="_level1_page_">News02</h1>
<h2>Infobox News02</h2>
<p>This box shows the content of the hidden page "News02".</p>
<hr>
<p><span class="tlid-translation translation" lang="en"><span class="" title="">The green header of this infobox is an h2 heading, an h1 heading looks the same.</span> <span title="">The other headings in an infobox (newsbox):</span></span></p>
<h3>Heading h3</h3>
<h4>Heading h4</h4>
<h5>Heading h5</h5>
<h6>Heading h6</h6>
<h1 class="_level1_page_">News03</h1>
<h2>Infobox News03</h2>
<p>This box shows the content of the hidden page "News03".</p>
<hr>
<p>Here you will find modern templates and plugins for CMSimple:</p>
<ul>
<li style="text-align: left;"><a href="https://www.ge-webdesign.de/cmsimpletemplates/?Template_Auswahl">CMSimple Templates »</a></li>
<li style="text-align: left;"><a href="https://www.ge-webdesign.de/cmsimpleplugins/">CMSimple Plugins »</a></li>
</ul>
<hr>
<p>Now have much fun and success with your new CMSimple Website.</p>
<p>Viel Spass und Erfolg mit Ihrer neuen CMSimple Website.</p>
